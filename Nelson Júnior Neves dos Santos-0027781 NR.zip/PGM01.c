#include <stdio.h>
#include <locale.h>


int main() 
{
	setlocale(LC_ALL,"portuguese");
    float din;//utilizei float porque contem numeros fracion�rios
    
    printf("Quanto de dinheiro voce tem? ");
    scanf("%f", &din);
	
	if (din>50)
	{
		printf("Amig�o v� ao cinema, voc� est� RICO");
	
	}else{
		printf("Amig�o fique em casa assistindo FAUST�O");
	}
	
	
	
	
	
	
	
	}   
